﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Automation1.Logger;

namespace UnitTestProject1
{   
    [TestClass]
    public class Activity1Facebook : EneidaTest
    {
        private bool startAsConsoleApp = false;

        public bool StartAsConsoleApp { get => startAsConsoleApp; set => startAsConsoleApp = value; }

        [TestInitialize] 
        public void BeforeEachTest()
        {
            InitializeFramework(StartAsConsoleApp);
            Pages.AmazonPage.InitElements();
        }        

        [TestCategory("SocialMedia"), Priority(1), TestMethod]
        public void AmazonTest()
        {
            Pages.AmazonPage
                .GoTo()
                .LoginWithCredentials();

            Pages.StandardMethods
                 .Wait(4000);

            Pages.AmazonPage.SearchProduct("Samsung Galaxy S9 64GB");
            Pages.AmazonPage.SelectFirstProduct();
            Pages.StandardMethods.Wait(2000);
            return;
            
            Pages.AmazonPage.AddToCart();

            Pages.StandardMethods.Wait(2000);

            Log.Info("All validation passed");
        }

        [TestCleanup]
        public void AfterEachTest()
        {
            CleanUpTest();
        }
    }
}